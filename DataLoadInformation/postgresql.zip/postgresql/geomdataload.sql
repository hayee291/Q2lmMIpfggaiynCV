SELECT COUNT(*) FROM busdata;
SELECT * FROM pg_extension;
CREATE EXTENSION postgis;
SELECT postgis_version();
ALTER TABLE busdata ADD COLUMN geom geometry;
SELECT * FROM busdata LIMIT 10;
UPDATE busdata SET geom = ST_SETSRID(ST_MAKEPOINT(lng,lat),4326); 
CREATE INDEX on busdata using gist(geom);